
public class Town {

}

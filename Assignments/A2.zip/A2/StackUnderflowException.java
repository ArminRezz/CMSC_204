public class StackUnderflowException extends Exception {
    public StackUnderflowException() {
        super("Stack overflow");
    }
}
public class InvalidNotationFormatException extends Exception {
    public InvalidNotationFormatException() {
        super("Invalid notation format");
    }
}